#!/bin/bash
# script restart service dropbear, webmin, squid3, openvpn, openssh
#
service dropbear restart
service webmin restart
service squid3 restart
service openvpn restart
service ssh restart
# restartnya agak lama :'v