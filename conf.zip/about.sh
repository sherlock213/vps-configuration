#!/bin/bash
#tentang ni script

clear
echo -e "Script Auto Install SSH & OpenVPN v1.0 Mod" 
echo -e ""
echo -e "untuk Debian 7 32 bit & 64 bit"
echo -e "untuk VPS yg pake KVM dan VMWare virtualization"
echo -e ""
echo -e "Original script by :"
echo -e "* Fornesia"
echo -e "* Rzengineer"
echo -e "* Fawzya"
echo -e "Mod by Bustami Arifin"
echo -e "Thanks buat kalian semua :'v"
echo -e ""
echo -e "Mod again by me (BAT)"
echo -e ""
echo -e "https://www.facebook.com/bustami.arifin.127"
echo -e "http://www.masarif.tk"
echo -e ""
