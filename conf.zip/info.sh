#!/bin/bash
#info

clear
echo "Informasi sistem:"
neofetch
echo -e "Mod by BAT"